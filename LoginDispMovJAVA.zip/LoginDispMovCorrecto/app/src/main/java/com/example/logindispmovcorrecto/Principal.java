package com.example.logindispmovcorrecto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Principal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal);
    }
}